import React from "react";
import { LINKS } from "../constants/links";

export default function WhatsAppButton({ phone = LINKS.whatsappPhone, message = LINKS.whatsappMessage }) {
  const href = `https://wa.me/${phone.replace(/\D/g,"")}?text=${encodeURIComponent(message)}`;
  return (
    <a className="whatsapp-btn" href={href} target="_blank" rel="noreferrer" aria-label="WhatsApp">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M20 11.5c0 4.694-3.806 8.5-8.5 8.5a8.47 8.47 0 0 1-4.027-1.02L3 21l2.06-4.317A8.471 8.471 0 0 1 3.5 11.5C3.5 6.806 7.306 3 12 3s8 3.806 8 8.5Z" stroke="white" strokeWidth="1.5"/>
        <path d="M8.5 9.5c0 3.5 3.5 6 5 6 .5 0 1.8-.5 2-1 .2-.5-.5-1.1-1-1.5-.4-.3-.9-.1-1.2.2l-.3.3c-.4.4-1 .3-1.5.1-.9-.4-1.8-1.3-2.2-2.2-.2-.5-.3-1.1.1-1.5l.3-.3c.3-.3.5-.8.2-1.2-.4-.5-1-1.2-1.5-1-.5.2-1 .9-1 1.1Z" fill="white"/>
      </svg>
    </a>
  );
}
