import React, { useState, useEffect } from "react";

export default function LeadPopup({ open, onClose }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  if (!open) return null;

  return (
    <div className={"lead-popup show" + (mounted ? "" : "")} role="dialog" aria-modal="true">
      <div className="box">
        <button className="close" onClick={onClose} aria-label="Kapat">✕</button>
        <h2>Birlikte büyütelim</h2>
        <p style={{color:"#c6c9e9", marginTop:4, marginBottom:14}}>
          Kısa formu doldurun; 24 saat içinde audit & büyüme planını gönderelim.
        </p>
        <form onSubmit={(e)=>{ e.preventDefault(); alert("Teşekkürler! Sizinle iletişime geçiyoruz."); onClose(); }}>
          <input placeholder="İsim" required />
          <input placeholder="Soyisim" required />
          <input type="email" placeholder="E‑posta" required />
          <input type="tel" placeholder="Telefon" required />
          <button type="submit">Gönder</button>
        </form>
      </div>
    </div>
  );
}
