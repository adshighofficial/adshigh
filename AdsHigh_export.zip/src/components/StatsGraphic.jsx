import React, { useEffect, useState } from "react";

export default function StatsGraphic(){
  const [tick, setTick] = useState(0);
  useEffect(()=>{
    const id = setInterval(()=> setTick(t => (t+1)%8), 1500);
    return ()=> clearInterval(id);
  },[]);

  const base = [8,12,16,12,18,20,14,10];
  const bars = base.map((v,i)=> v + (i===3 ? (tick%2?4:0): 0));

  return (
    <div className="mini-graph">
      <svg viewBox="0 0 200 90" preserveAspectRatio="xMidYMid meet">
        <defs>
          <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#8B5CF6"/>
            <stop offset="100%" stopColor="#67E8F9"/>
          </linearGradient>
        </defs>
        <rect x="2" y="2" width="196" height="86" rx="14" fill="url(#panelGrad)" opacity="0"/>
        {bars.map((h, i) => (
          <rect key={i} x={16 + i*18} y={70-h*3} width="10" height={h*3} rx="3" fill="url(#g1)">
            <animate attributeName="height" values="{h*3};{h*3+6};{h*3}" dur="2.6s" repeatCount="indefinite"/>
            <animate attributeName="y" values="{70-h*3};{70-(h*3+6)};{70-h*3}" dur="2.6s" repeatCount="indefinite"/>
          </rect>
        ))}
        <defs>
          <radialGradient id="panelGrad" cx="70%" cy="20%" r="90%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.06"/>
            <stop offset="100%" stopColor="#000000" stopOpacity="0.0"/>
          </radialGradient>
        </defs>
        <rect x="2" y="2" width="196" height="86" rx="14" fill="url(#panelGrad)" stroke="rgba(255,255,255,.08)"/>
      </svg>
    </div>
  );
}
