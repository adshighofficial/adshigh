import React from "react";

const ITEMS = ["Google","Meta","TikTok","LinkedIn","Snap","Yandex","RTB","Adjust","GA4"];
export default function Marquee() {
  const row = [...ITEMS, ...ITEMS, ...ITEMS];
  return (
    <div className="logos-marquee">
      <div className="marquee-rail">
        <div className="marquee-track">
          {row.map((label, i) => (
            <span className="marquee-pill" key={i}>{label}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
