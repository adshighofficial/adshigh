// src/constants/links.js
export const LINKS = {
  email: "mailto:info@adshigh.com",
  linkedin: "https://www.linkedin.com/company/adshigh",
  instagram: "https://www.instagram.com/adshighofficial",
  facebook: "https://www.facebook.com/profile.php?id=61579677954876",
  whatsappPhone: "+905551112233",
  whatsappMessage: "Merhaba! Bilgi almak istiyorum."
};
