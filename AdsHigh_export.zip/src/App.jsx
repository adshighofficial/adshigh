import React, { useEffect, useState } from "react";
import "./index.css";
import "./theme-override.css";
import { LINKS } from "./constants/links";
import Marquee from "./components/Marquee";
import LeadPopup from "./components/LeadPopup";
import WhatsAppButton from "./components/WhatsAppButton";
import StatsGraphic from "./components/StatsGraphic";

export default function App(){
  const [leadOpen, setLeadOpen] = useState(false);
  useEffect(()=>{
    const t = setTimeout(()=> setLeadOpen(true), 2000);
    return ()=> clearTimeout(t);
  },[]);

  return (
    <>
      <header className="header">
        <div className="container bar">
          <div className="site-logo">
            <span className="ads">Ads</span><span className="high">High</span>
          </div>
          <nav className="nav">
            <a href="#about">Hakkımızda</a>
            <a href="#contact">İletişim</a>
            <a href="#contact" className="btn" style={{padding:"8px 14px"}}>Teklif Al</a>
          </nav>
        </div>
      </header>

      {/* HERO */}
      <section className="hero">
        <div className="container">
          <div className="badge">Veri Odaklı · Performans Pazarlama</div>
          <h1 className="headline">Bütçeniz <span className="logo-gradient">daha akıllı</span> çalışsın.</h1>
          <p className="subcopy">
            Google, Sosyal Medya ve 3. Parti kampanyalarınızı gerçek zamanlı verilerle optimize ederiz;
            tıklamayı değil <b>satışı</b> ölçeriz.
          </p>
          <div style={{marginTop:18}}>
            <button className="btn" onClick={()=> setLeadOpen(true)}>Audit Al</button>
          </div>
          <Marquee/>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="section">
        <div className="container">
          <h2 style={{margin:"0 0 18px"}}>Hizmetlerimiz</h2>
          <div className="cards">
            <article className="card">
              <div className="card-icon">✅</div>
              <h3>Google Ads Reklamları</h3>
              <p>Search, Performance Max, YouTube ile tam hunili büyüme. POAS/ROAS hedefli kurgu, anlık bid optimizasyonu.</p>
              <a href="#contact">Daha Fazlası →</a>
            </article>
            <article className="card">
              <div className="card-icon">🧩</div>
              <h3>Sosyal Medya Reklamları</h3>
              <p>Meta & TikTok’ta kreatif test çerçevesi, çoklu kitle stratejisi ve katalog entegrasyonu.</p>
              <a href="#contact">Daha Fazlası →</a>
            </article>
            <article className="card">
              <div className="card-icon">📊</div>
              <h3>Analiz & Raporlama</h3>
              <p>Server-side tracking, GA4 + Consent Mode v2 uyumu, net dashboard’lar ve haftalık raporlama.</p>
              <a href="#contact">Daha Fazlası →</a>
            </article>
          </div>
        </div>
      </section>

      {/* ABOUT + GRAPH */}
      <section id="about" className="section" style={{paddingTop:48}}>
        <div className="container" style={{display:"grid",gridTemplateColumns:"1.2fr .8fr",gap:28,alignItems:"center"}}>
          <div>
            <h2>Performans Pazarlama Nedir?</h2>
            <p> Bütçenizi ölçülebilir hedeflere bağlayan sonuç odaklı bir yaklaşımdır.
              Google, Sosyal Medya ve 3. parti platformlarda kurduğumuz veri mimarisiyle
              <b> tıklamayı değil satış</b> ve kârlılığı ölçeriz.
            </p>
            <p>
              Kreatif test çerçevesi, POAS/ROAS optimizasyonu ve server‑side tracking ile şeffaf dashboard’lar ve
              haftalık planlarla sonucu net görürsünüz.
            </p>
          </div>
          <div style={{display:"flex",justifyContent:"center"}}>
            <StatsGraphic/>
          </div>
        </div>
      </section>

      {/* REFS */}
      <section className="refs">
        <div className="container">
          <h2 style={{margin:"0 0 18px"}}>Referanslarımız</h2>
          <div className="ref-grid">
            {["/refs/bsl.png","/refs/vatkali.svg","/refs/gardrops.png","/refs/gulaylar.webp","/refs/mealboxlogo.webp"].map((src, i)=>(
              <div key={i} className="ref-card">
                <img src={src} alt={"ref-"+i} style={{maxHeight:44,width:"auto"}}/>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer id="contact">
        <div className="container" style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:16}}>
          <div className="site-logo"><span className="ads">Ads</span><span className="high">High</span></div>
          <div className="footer-socials">
            <a href={LINKS.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn">in</a>
            <a href={LINKS.instagram} target="_blank" rel="noreferrer" aria-label="Instagram">ig</a>
            <a href={LINKS.facebook} target="_blank" rel="noreferrer" aria-label="Facebook">f</a>
          </div>
        </div>
        <div className="container" style={{marginTop:12,color:"#9aa1d3"}}>
          © 2025 AdsHigh · Gizlilik · Çerezler · KVKK
        </div>
      </footer>

      <WhatsAppButton/>
      <LeadPopup open={leadOpen} onClose={()=> setLeadOpen(false)}/>
    </>
  );
}
